<?php
/**
 * Renders the custom SSO login page at /?cad_dev_login=1
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Cad_Dev_Login_Page {

    public function __construct() {
        add_action( 'init',              [ $this, 'handle_login_request' ], 1 );
        add_action( 'template_redirect', [ $this, 'maybe_render_login_page' ] );
    }

    /**
     * When the user clicks "Login with Cad Dev SSO", build the SSO URL and redirect.
     */
    public function handle_login_request() {
        if ( empty( $_GET['cad_dev_do_login'] ) ) {
            return;
        }

        $sso_url = get_option( 'cad_dev_sso_url', '' );
        if ( empty( $sso_url ) ) {
            wp_die( 'Cad Dev SSO: SSO URL not configured. Go to Settings → Cad Dev SSO.', 'SSO Error', [ 'response' => 500 ] );
        }

        // Generate a state token to prevent CSRF
        $state = wp_generate_password( 32, false );
        set_transient( 'cad_dev_state_' . $state, '1', 10 * MINUTE_IN_SECONDS );

        // Carry the fingerprint hash through the OAuth round-trip so the callback
        // handler can save the signal after login. Hash was set by the Layer 1 assess.
        $fp_hash = sanitize_text_field( wp_unslash( $_GET['cad_dev_fp_hash'] ?? '' ) );
        if ( ! empty( $fp_hash ) && preg_match( '/^[a-f0-9]{64}$/', $fp_hash ) ) {
            set_transient( 'cad_dev_fp_' . $state, $fp_hash, 15 * MINUTE_IN_SECONDS );
        }

        $callback_url = add_query_arg( 'cad_dev_callback', '1', home_url( '/' ) );

        $redirect = add_query_arg(
            [
                'redirect_uri' => rawurlencode( $callback_url ),
                'state'        => $state,
            ],
            trailingslashit( $sso_url ) . 'auth/wordpress'
        );

        wp_redirect( $redirect );
        exit;
    }

    /**
     * Render the login page HTML when ?cad_dev_login=1 is in the URL.
     */
    public function maybe_render_login_page() {
        if ( empty( $_GET['cad_dev_login'] ) ) {
            return;
        }

        // Already logged in? Send to admin.
        if ( is_user_logged_in() ) {
            wp_safe_redirect( admin_url() );
            exit;
        }

        $sso_configured    = ! empty( get_option( 'cad_dev_sso_url', '' ) );
        $plugin_configured = ! empty( get_option( 'cad_dev_plugin_secret', '' ) );
        $step              = sanitize_text_field( $_GET['cad_dev_step'] ?? 'default' );
        $session_id        = sanitize_text_field( $_GET['cad_dev_session'] ?? '' );
        $error_message     = sanitize_text_field( urldecode( $_GET['cad_dev_error'] ?? '' ) );

        include CAD_DEV_PLUGIN_DIR . 'templates/login-page.php';
        exit;
    }
}
