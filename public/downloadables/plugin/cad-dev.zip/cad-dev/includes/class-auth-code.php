<?php
/**
 * Handles the auth-code (OTP) login flow.
 *
 * Flow:
 *  1. User clicks "Login with Auth Code" → POST ?cad_dev_request_code=1
 *  2. Plugin calls web app POST /auth/code/request → gets otp_token
 *  3. otp_token stored in a transient; user shown a code entry form
 *  4. User submits 6-digit code → POST ?cad_dev_verify_code=1
 *  5. Plugin calls web app POST /auth/code/verify → gets login_token (RS256 JWT)
 *  6. Plugin verifies login_token locally and logs the user in
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Cad_Dev_Auth_Code {

    public function __construct() {
        add_action( 'init', [ $this, 'handle_request_code' ], 1 );
        add_action( 'init', [ $this, 'handle_verify_code' ],  1 );
    }

    // ── Step 1: Request a code ────────────────────────────────────────────────

    public function handle_request_code() {
        if ( empty( $_POST['cad_dev_request_code'] ) ) {
            return;
        }

        if ( ! check_admin_referer( 'cad_dev_request_code', 'cad_dev_nonce' ) ) {
            wp_die( 'Security check failed.', 'Error', [ 'response' => 403 ] );
        }

        $sso_url       = get_option( 'cad_dev_sso_url', '' );
        $plugin_secret = get_option( 'cad_dev_plugin_secret', '' );

        if ( empty( $sso_url ) || empty( $plugin_secret ) ) {
            wp_die( 'Cad Dev SSO: Auth code login is not fully configured.', 'SSO Error', [ 'response' => 500 ] );
        }

        $response = wp_remote_post(
            trailingslashit( $sso_url ) . 'auth/code/request',
            [
                'headers' => [
                    'x-plugin-secret' => $plugin_secret,
                    'Content-Type'    => 'application/json',
                ],
                'body'      => '{}',
                'timeout'   => 15,
                'sslverify' => true,
            ]
        );

        if ( is_wp_error( $response ) ) {
            wp_die(
                'Cad Dev SSO: Could not reach the SSO server: ' . esc_html( $response->get_error_message() ),
                'SSO Error',
                [ 'response' => 500 ]
            );
        }

        $body        = json_decode( wp_remote_retrieve_body( $response ), true );
        $status_code = wp_remote_retrieve_response_code( $response );

        if ( $status_code !== 200 || empty( $body['otp_token'] ) ) {
            $error = $body['error'] ?? 'Unknown error';
            wp_die( 'Cad Dev SSO: ' . esc_html( $error ), 'SSO Error', [ 'response' => $status_code ] );
        }

        // Store the OTP token in a transient keyed by a random session ID
        $session_id = wp_generate_password( 32, false );
        set_transient( 'cad_dev_otp_' . $session_id, $body['otp_token'], 15 * MINUTE_IN_SECONDS );

        // Carry the fingerprint hash so we can save the trusted signal after verify
        $fp_hash = sanitize_text_field( wp_unslash( $_POST['cad_dev_fp_hash'] ?? '' ) );
        if ( ! empty( $fp_hash ) && preg_match( '/^[a-f0-9]{64}$/', $fp_hash ) ) {
            set_transient( 'cad_dev_fp_' . $session_id, $fp_hash, 15 * MINUTE_IN_SECONDS );
        }

        // Redirect to the code-entry step of the login page
        wp_redirect( add_query_arg(
            [
                'cad_dev_login'   => '1',
                'cad_dev_step'    => 'enter_code',
                'cad_dev_session' => $session_id,
            ],
            home_url( '/' )
        ) );
        exit;
    }

    // ── Step 2: Verify the code and log in ───────────────────────────────────

    public function handle_verify_code() {
        if ( empty( $_POST['cad_dev_verify_code'] ) ) {
            return;
        }

        if ( ! check_admin_referer( 'cad_dev_verify_code', 'cad_dev_nonce' ) ) {
            wp_die( 'Security check failed.', 'Error', [ 'response' => 403 ] );
        }

        $session_id = sanitize_text_field( wp_unslash( $_POST['cad_dev_session'] ?? '' ) );
        $code       = sanitize_text_field( wp_unslash( $_POST['cad_dev_code'] ?? '' ) );

        if ( empty( $session_id ) || empty( $code ) ) {
            wp_die( 'Cad Dev SSO: Missing session or code.', 'SSO Error', [ 'response' => 400 ] );
        }

        if ( ! preg_match( '/^\d{6}$/', $code ) ) {
            wp_die( 'Cad Dev SSO: Invalid code format.', 'SSO Error', [ 'response' => 400 ] );
        }

        // Retrieve and immediately consume the OTP token (one-time use)
        $otp_token = get_transient( 'cad_dev_otp_' . $session_id );
        if ( $otp_token === false ) {
            wp_die( 'Cad Dev SSO: Session expired. Please request a new code.', 'SSO Error', [ 'response' => 403 ] );
        }
        delete_transient( 'cad_dev_otp_' . $session_id );

        $sso_url       = get_option( 'cad_dev_sso_url', '' );
        $plugin_secret = get_option( 'cad_dev_plugin_secret', '' );

        // Call the web app to verify the code
        $response = wp_remote_post(
            trailingslashit( $sso_url ) . 'auth/code/verify',
            [
                'headers' => [
                    'x-plugin-secret' => $plugin_secret,
                    'Content-Type'    => 'application/json',
                ],
                'body'      => wp_json_encode( [ 'otp_token' => $otp_token, 'code' => $code ] ),
                'timeout'   => 15,
                'sslverify' => true,
            ]
        );

        if ( is_wp_error( $response ) ) {
            wp_die(
                'Cad Dev SSO: Could not reach the SSO server: ' . esc_html( $response->get_error_message() ),
                'SSO Error',
                [ 'response' => 500 ]
            );
        }

        $body        = json_decode( wp_remote_retrieve_body( $response ), true );
        $status_code = wp_remote_retrieve_response_code( $response );

        if ( $status_code !== 200 || empty( $body['login_token'] ) ) {
            // Wrong code — redirect back to the form with an error message
            wp_redirect( add_query_arg(
                [
                    'cad_dev_login'   => '1',
                    'cad_dev_step'    => 'enter_code',
                    'cad_dev_session' => $session_id,
                    'cad_dev_error'   => rawurlencode( $body['error'] ?? 'Incorrect code.' ),
                ],
                home_url( '/' )
            ) );
            exit;
        }

        // Verify the login JWT locally (same as the Google SSO flow)
        $public_key      = get_option( 'cad_dev_public_key', '' );
        $expected_issuer = get_option( 'cad_dev_sso_url', '' );
        $verifier        = new Cad_Dev_JWT_Verifier( $public_key, $expected_issuer );
        $payload         = $verifier->verify( $body['login_token'] );

        if ( ! $payload ) {
            wp_die( 'Cad Dev SSO: Invalid login token received from server.', 'SSO Error', [ 'response' => 403 ] );
        }

        // Replay prevention
        $jti_key = 'cad_dev_jti_' . hash( 'sha256', $payload['jti'] );
        if ( get_transient( $jti_key ) !== false ) {
            wp_die( 'Cad Dev SSO: Token already used.', 'SSO Error', [ 'response' => 403 ] );
        }
        set_transient( $jti_key, '1', 6 * MINUTE_IN_SECONDS );

        $email = sanitize_email( $payload['email'] ?? '' );
        $name  = sanitize_text_field( $payload['name'] ?? '' );

        if ( ! is_email( $email ) ) {
            wp_die( 'Cad Dev SSO: Invalid email in token.', 'SSO Error', [ 'response' => 400 ] );
        }

        // Find or create the WP user
        $user = get_user_by( 'email', $email );
        if ( ! $user ) {
            $username = sanitize_user( strstr( $email, '@', true ) );
            if ( username_exists( $username ) ) {
                $username = $username . '_' . wp_generate_password( 4, false );
            }
            $role    = get_option( 'cad_dev_default_role', 'administrator' );
            $user_id = wp_insert_user( [
                'user_login'   => $username,
                'user_email'   => $email,
                'display_name' => $name ?: $username,
                'user_pass'    => wp_generate_password( 32 ),
                'role'         => $role,
            ] );
            if ( is_wp_error( $user_id ) ) {
                wp_die(
                    'Cad Dev SSO: Failed to create user: ' . esc_html( $user_id->get_error_message() ),
                    'SSO Error',
                    [ 'response' => 500 ]
                );
            }
            $user = get_user_by( 'id', $user_id );
        }

        // Log the user in
        wp_set_current_user( $user->ID );
        wp_set_auth_cookie( $user->ID, true );
        do_action( 'wp_login', $user->user_login, $user );

        if ( empty( get_option( 'cad_dev_owner_email', '' ) ) ) {
            update_option( 'cad_dev_owner_email', $user->user_email );
        }

        // Save trusted signal so this device is auto-trusted next time (Layer 1)
        $fp_hash = get_transient( 'cad_dev_fp_' . $session_id );
        if ( $fp_hash ) {
            delete_transient( 'cad_dev_fp_' . $session_id );
            cad_dev_save_trusted_signal( $user->ID, cad_dev_get_client_ip(), $fp_hash );
        }
        cad_dev_set_session_cookie( $user->user_email );
        cad_dev_register_with_web_app();

        wp_safe_redirect( admin_url() );
        exit;
    }
}
