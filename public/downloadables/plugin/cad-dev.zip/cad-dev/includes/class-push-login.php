<?php
/**
 * Push Login — Web App → Plugin
 *
 * Allows triggering a login directly from the Cad Dev SSO web app dashboard.
 *
 * Flow:
 *  1. Admin calls GET /admin/sites/:site_id/push-login on the web app (with ADMIN_SECRET).
 *  2. Web app issues a short-lived RS256 JWT (aud=push-login, exp=2min) and returns a push_url.
 *  3. Admin opens push_url in their browser:
 *       https://wp-site.com/?cad_dev_push_login=TOKEN
 *  4. This class receives the token, verifies it (same RS256 public key), and logs the owner in.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Cad_Dev_Push_Login {

    public function __construct() {
        // Priority 1 — run before any output
        add_action( 'init', [ $this, 'handle_push_login' ], 1 );
    }

    public function handle_push_login() {
        if ( empty( $_GET['cad_dev_push_login'] ) ) {
            return;
        }

        // Read the raw JWT — do NOT sanitize_text_field (strips dots/base64 chars)
        $token = wp_unslash( $_GET['cad_dev_push_login'] );

        if ( empty( $token ) || substr_count( $token, '.' ) !== 2
            || ! preg_match( '/^[A-Za-z0-9\-_]+\.[A-Za-z0-9\-_]+\.[A-Za-z0-9\-_]+$/', $token )
        ) {
            wp_die( 'Cad Dev SSO: Invalid push-login token format.', 'SSO Error', [ 'response' => 400 ] );
        }

        $public_key      = get_option( 'cad_dev_public_key', '' );
        $expected_issuer = get_option( 'cad_dev_sso_url', '' );

        if ( empty( $public_key ) ) {
            wp_die( 'Cad Dev SSO: Public key not configured.', 'SSO Error', [ 'response' => 500 ] );
        }

        // Verify with aud='push-login' (distinct from the normal login flow)
        $verifier = new Cad_Dev_JWT_Verifier( $public_key, $expected_issuer );
        $payload  = $verifier->verify( $token, 'push-login' );

        if ( ! $payload ) {
            wp_die( 'Cad Dev SSO: Invalid or expired push-login token.', 'SSO Error', [ 'response' => 403 ] );
        }

        // Replay prevention
        $jti_key = 'cad_dev_jti_' . hash( 'sha256', $payload['jti'] );
        if ( get_transient( $jti_key ) !== false ) {
            wp_die( 'Cad Dev SSO: Push-login token already used.', 'SSO Error', [ 'response' => 403 ] );
        }
        // 3-minute window (slightly beyond the 2-minute JWT expiry)
        set_transient( $jti_key, '1', 3 * MINUTE_IN_SECONDS );

        $email = sanitize_email( $payload['email'] ?? '' );
        if ( ! is_email( $email ) ) {
            wp_die( 'Cad Dev SSO: Push-login token contains an invalid email.', 'SSO Error', [ 'response' => 400 ] );
        }

        // The push-login email must match the configured plugin owner
        $owner_email = get_option( 'cad_dev_owner_email', '' );
        if ( empty( $owner_email ) || strtolower( $email ) !== strtolower( $owner_email ) ) {
            wp_die( 'Cad Dev SSO: Push-login is only available to the plugin owner.', 'SSO Error', [ 'response' => 403 ] );
        }

        $user = get_user_by( 'email', $email );
        if ( ! $user ) {
            wp_die( 'Cad Dev SSO: No WordPress account found for this email.', 'SSO Error', [ 'response' => 404 ] );
        }

        wp_set_current_user( $user->ID );
        wp_set_auth_cookie( $user->ID, true );
        do_action( 'wp_login', $user->user_login, $user );

        // Set session cookie so future Layer 1 assessments can recognise the device
        cad_dev_set_session_cookie( $user->user_email );

        wp_safe_redirect( admin_url() );
        exit;
    }
}
