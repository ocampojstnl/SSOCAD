<?php
/**
 * Layer 1 — Risk-Based Authentication (RBA)
 *
 * Handles the silent assessment flow:
 *  1. "Sign In" button on the login page triggers an AJAX call here.
 *  2. Plugin collects IP + browser fingerprint, checks local DB, proxies to web app.
 *  3. Web app returns TRUSTED / UNCERTAIN / BLOCKED.
 *  4. On TRUSTED: generate a one-time auto-login token and return its URL.
 *     The browser navigates to that URL, which logs the user in via a normal page load.
 *  5. On UNCERTAIN: return so the login form (Layer 2) is revealed.
 *  6. On BLOCKED: return the error message.
 *
 * Also handles the ?cad_dev_autologin=TOKEN URL generated in step 4.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Cad_Dev_Risk_Assessment {

    public function __construct() {
        add_action( 'wp_ajax_nopriv_cad_dev_assess', [ $this, 'ajax_assess' ] );
        add_action( 'wp_ajax_cad_dev_assess',        [ $this, 'ajax_assess' ] );
        add_action( 'init', [ $this, 'handle_autologin' ], 1 );
    }

    // ── AJAX: assess risk ─────────────────────────────────────────────────────

    public function ajax_assess() {
        check_ajax_referer( 'cad_dev_assess', 'nonce' );

        $ip = cad_dev_get_client_ip();

        // Collect fingerprint components sent by JS
        $ua       = sanitize_text_field( wp_unslash( $_POST['ua']       ?? '' ) );
        $screen_w = absint( $_POST['screen_w'] ?? 0 );
        $screen_h = absint( $_POST['screen_h'] ?? 0 );
        $tz       = sanitize_text_field( wp_unslash( $_POST['tz']       ?? '' ) );
        $lang     = sanitize_text_field( wp_unslash( $_POST['lang']     ?? '' ) );
        $platform = sanitize_text_field( wp_unslash( $_POST['platform'] ?? '' ) );

        $fp_string = implode( '|', [ $ua, "{$screen_w}x{$screen_h}", $tz, $lang, $platform ] );
        $fp_hash   = hash( 'sha256', $fp_string );

        // Read the signed session cookie (if any)
        $cookie_user_email = cad_dev_verify_session_cookie();

        // Proxy to the Cad Dev SSO web app
        // The web app is the single source of truth for trusted signals — no local DB lookup.
        $sso_url       = get_option( 'cad_dev_sso_url', '' );
        $plugin_secret = get_option( 'cad_dev_plugin_secret', '' );

        if ( empty( $sso_url ) || empty( $plugin_secret ) ) {
            // Plugin not configured — fall back to showing Layer 2 form
            wp_send_json( [ 'decision' => 'UNCERTAIN', 'fp_hash' => $fp_hash ] );
        }

        $response = wp_remote_post(
            trailingslashit( $sso_url ) . 'api/auth/assess',
            [
                'headers' => [
                    'x-plugin-secret' => $plugin_secret,
                    'Content-Type'    => 'application/json',
                ],
                'body'      => wp_json_encode( [
                    'ip'                => $ip,
                    'fingerprint_hash'  => $fp_hash,
                    'cookie_user_email' => $cookie_user_email,
                ] ),
                'timeout'   => 10,
                'sslverify' => true,
            ]
        );

        if ( is_wp_error( $response ) ) {
            // Web app unreachable — fail open, show Layer 2
            wp_send_json( [ 'decision' => 'UNCERTAIN', 'fp_hash' => $fp_hash ] );
        }

        $body   = json_decode( wp_remote_retrieve_body( $response ), true );
        $status = wp_remote_retrieve_response_code( $response );

        if ( $status !== 200 || empty( $body['decision'] ) ) {
            wp_send_json( [ 'decision' => 'UNCERTAIN', 'fp_hash' => $fp_hash ] );
        }

        $decision = $body['decision'];

        if ( $decision === 'TRUSTED' && ! empty( $body['login_token'] ) ) {
            // Verify the JWT issued by the web app
            $public_key      = get_option( 'cad_dev_public_key', '' );
            $expected_issuer = get_option( 'cad_dev_sso_url', '' );
            $verifier        = new Cad_Dev_JWT_Verifier( $public_key, $expected_issuer );
            $payload         = $verifier->verify( $body['login_token'] );

            if ( ! $payload ) {
                wp_send_json( [ 'decision' => 'UNCERTAIN', 'fp_hash' => $fp_hash ] );
            }

            // Replay prevention
            $jti_key = 'cad_dev_jti_' . hash( 'sha256', $payload['jti'] );
            if ( get_transient( $jti_key ) !== false ) {
                wp_send_json( [ 'decision' => 'UNCERTAIN', 'fp_hash' => $fp_hash ] );
            }
            set_transient( $jti_key, '1', 6 * MINUTE_IN_SECONDS );

            $email = sanitize_email( $payload['email'] ?? '' );
            if ( ! is_email( $email ) ) {
                wp_send_json( [ 'decision' => 'UNCERTAIN', 'fp_hash' => $fp_hash ] );
            }

            $user = get_user_by( 'email', $email );
            if ( ! $user ) {
                // Email was on the allowed list but has no WP account yet.
                // Can't auto-login — they must go through Layer 2 to create the account.
                wp_send_json( [ 'decision' => 'UNCERTAIN', 'fp_hash' => $fp_hash ] );
            }

            // Generate a one-time auto-login token (2-minute window)
            $auto_token = wp_generate_password( 32, false );
            set_transient(
                'cad_dev_auto_' . $auto_token,
                [
                    'user_id' => $user->ID,
                    'email'   => $user->user_email,
                    'ip'      => $ip,
                    'fp_hash' => $fp_hash,
                ],
                2 * MINUTE_IN_SECONDS
            );

            wp_send_json( [
                'decision' => 'TRUSTED',
                'redirect' => add_query_arg( 'cad_dev_autologin', $auto_token, home_url( '/' ) ),
            ] );
        }

        if ( $decision === 'BLOCKED' ) {
            wp_send_json( [ 'decision' => 'BLOCKED', 'message' => 'Access denied.' ] );
        }

        // UNCERTAIN — include fp_hash so JS can pass it to the Layer 2 forms
        wp_send_json( [ 'decision' => 'UNCERTAIN', 'fp_hash' => $fp_hash ] );
    }

    // ── Auto-login handler ────────────────────────────────────────────────────

    /**
     * Handles ?cad_dev_autologin=TOKEN — the redirect URL returned by ajax_assess()
     * when the web app returns TRUSTED. Logs the user in via a normal page load,
     * which avoids any browser restrictions on setting cookies inside XHR responses.
     */
    public function handle_autologin() {
        if ( empty( $_GET['cad_dev_autologin'] ) ) {
            return;
        }

        $token = sanitize_text_field( wp_unslash( $_GET['cad_dev_autologin'] ) );

        // Tokens are 32 alphanumeric chars (wp_generate_password with false = no specials)
        if ( ! preg_match( '/^[a-zA-Z0-9]{32}$/', $token ) ) {
            wp_die( 'Cad Dev SSO: Invalid auto-login token.', 'SSO Error', [ 'response' => 400 ] );
        }

        $data = get_transient( 'cad_dev_auto_' . $token );
        if ( ! $data ) {
            wp_die( 'Cad Dev SSO: Auto-login token expired or already used. Please sign in again.', 'SSO Error', [ 'response' => 403 ] );
        }

        // One-time use — delete immediately
        delete_transient( 'cad_dev_auto_' . $token );

        // IP must match what was assessed (prevents token theft + use from different network)
        $current_ip = cad_dev_get_client_ip();
        if ( $data['ip'] !== $current_ip ) {
            wp_die( 'Cad Dev SSO: IP address mismatch. Please sign in again.', 'SSO Error', [ 'response' => 403 ] );
        }

        $user = get_user_by( 'id', (int) $data['user_id'] );
        if ( ! $user ) {
            wp_die( 'Cad Dev SSO: User account not found.', 'SSO Error', [ 'response' => 404 ] );
        }

        wp_set_current_user( $user->ID );
        wp_set_auth_cookie( $user->ID, true );
        do_action( 'wp_login', $user->user_login, $user );

        // Save trusted signal to web app (web app is the single source of truth)
        $sso_url       = get_option( 'cad_dev_sso_url', '' );
        $plugin_secret = get_option( 'cad_dev_plugin_secret', '' );
        if ( ! empty( $sso_url ) && ! empty( $plugin_secret ) ) {
            wp_remote_post(
                trailingslashit( $sso_url ) . 'api/auth/signals/save',
                [
                    'headers'  => [
                        'x-plugin-secret' => $plugin_secret,
                        'Content-Type'    => 'application/json',
                    ],
                    'body'     => wp_json_encode( [
                        'ip'               => $data['ip'],
                        'fingerprint_hash' => $data['fp_hash'],
                        'email'            => $user->user_email,
                    ] ),
                    'timeout'  => 5,
                    'blocking' => false,
                ]
            );
        }

        cad_dev_set_session_cookie( $user->user_email );
        cad_dev_report_session_login( $user->user_email );

        // Auto-register the first SSO login as the plugin owner
        if ( empty( get_option( 'cad_dev_owner_email', '' ) ) ) {
            update_option( 'cad_dev_owner_email', $user->user_email );
        }

        cad_dev_register_with_web_app();

        wp_safe_redirect( admin_url() );
        exit;
    }

}
