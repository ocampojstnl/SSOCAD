<?php
/**
 * Minimal RS256 JWT verifier — no external dependencies required.
 * Uses PHP's built-in openssl_verify().
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Cad_Dev_JWT_Verifier {

    /** @var string PEM-encoded RSA public key */
    private $public_key;

    /** @var string Expected issuer (APP_URL of the Cad Dev SSO web app) */
    private $expected_issuer;

    public function __construct( $public_key_pem, $expected_issuer = '' ) {
        $this->public_key      = $public_key_pem;
        $this->expected_issuer = rtrim( $expected_issuer, '/' );
    }

    /**
     * Verify and decode a JWT token.
     *
     * @param  string $token            Raw JWT string (not sanitized — caller must pass the raw value).
     * @param  string $expected_audience Expected 'aud' claim. Defaults to 'wordpress-sso'.
     * @return array|false              Decoded payload on success, false on any failure.
     */
    public function verify( $token, $expected_audience = 'wordpress-sso' ) {
        // Basic format check — JWTs are exactly 3 base64url segments separated by dots
        if ( ! is_string( $token ) || substr_count( $token, '.' ) !== 2 ) {
            return false;
        }

        $parts = explode( '.', $token );
        list( $header_b64, $payload_b64, $sig_b64 ) = $parts;

        // --- Decode and validate header ---
        $header = json_decode( $this->base64url_decode( $header_b64 ), true );
        if ( ! is_array( $header ) || ( $header['alg'] ?? '' ) !== 'RS256' || ( $header['typ'] ?? '' ) !== 'JWT' ) {
            return false;
        }

        // --- Verify RSA signature first (fail fast) ---
        $public_key = openssl_pkey_get_public( $this->public_key );
        if ( ! $public_key ) {
            error_log( 'Cad Dev SSO: Failed to load RSA public key.' );
            return false;
        }

        $signature = $this->base64url_decode( $sig_b64 );
        $data      = $header_b64 . '.' . $payload_b64;
        $verified  = openssl_verify( $data, $signature, $public_key, OPENSSL_ALGO_SHA256 );

        if ( $verified !== 1 ) {
            return false;
        }

        // --- Decode payload ---
        $payload = json_decode( $this->base64url_decode( $payload_b64 ), true );
        if ( ! is_array( $payload ) ) {
            return false;
        }

        $now = time();

        // --- Check expiration (exp) ---
        if ( ! isset( $payload['exp'] ) || (int) $payload['exp'] < $now ) {
            return false;
        }

        // --- Check not-before (nbf) if present ---
        if ( isset( $payload['nbf'] ) && (int) $payload['nbf'] > $now ) {
            return false;
        }

        // --- Check issued-at sanity: reject tokens issued more than 10 min in the future ---
        if ( isset( $payload['iat'] ) && (int) $payload['iat'] > $now + 600 ) {
            return false;
        }

        // --- Check audience ---
        if ( ( $payload['aud'] ?? '' ) !== $expected_audience ) {
            return false;
        }

        // --- Check issuer ---
        if ( ! empty( $this->expected_issuer ) ) {
            if ( rtrim( $payload['iss'] ?? '', '/' ) !== $this->expected_issuer ) {
                return false;
            }
        }

        // --- Check jti exists (required for replay prevention in the handler) ---
        if ( empty( $payload['jti'] ) || ! is_string( $payload['jti'] ) ) {
            return false;
        }

        return $payload;
    }

    private function base64url_decode( $input ) {
        $remainder = strlen( $input ) % 4;
        if ( $remainder ) {
            $input .= str_repeat( '=', 4 - $remainder );
        }
        return base64_decode( strtr( $input, '-_', '+/' ) );
    }
}
