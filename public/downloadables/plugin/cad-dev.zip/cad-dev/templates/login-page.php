<?php
/**
 * Login page template for the Cad Dev SSO plugin.
 *
 * Variables available:
 *   $sso_configured    bool   - true if SSO URL is set
 *   $plugin_configured bool   - true if plugin secret is set (auth code available)
 *   $step              string - 'default' or 'enter_code'
 *   $session_id        string - OTP session ID (on enter_code step)
 *   $error_message     string - error to show (optional)
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$css_url   = CAD_DEV_PLUGIN_URL . 'assets/css/login.css?v=' . CAD_DEV_VERSION;
$blog_name = get_bloginfo( 'name' );
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo( 'charset' ); ?>" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title><?php printf( esc_html__( 'Sign In — %s', 'cad-dev' ), esc_html( $blog_name ) ); ?></title>
  <link rel="stylesheet" href="<?php echo esc_url( $css_url ); ?>" />
  <?php do_action( 'login_enqueue_scripts' ); ?>
</head>
<body class="cad-dev-login-body">

  <div class="cad-dev-login-card">

    <!-- Header -->
    <div class="cad-dev-header">
      <svg class="cad-dev-logo" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round">
        <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
        <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
      </svg>
      <div>
        <h1 class="cad-dev-site-name"><?php echo esc_html( $blog_name ); ?></h1>
        <p class="cad-dev-subtitle">Developer Access Portal</p>
      </div>
    </div>

    <?php if ( ! empty( $error_message ) ) : ?>
      <div class="cad-dev-error">
        <?php echo esc_html( $error_message ); ?>
      </div>
    <?php endif; ?>

    <?php if ( $step === 'enter_code' ) : ?>

      <!-- ── Code entry ─────────────────────────────────────────────── -->
      <p class="cad-dev-code-hint">
        Get your 6-digit code from the Cad Dev SSO web app and enter it below.
      </p>

      <form method="post" action="<?php echo esc_url( home_url( '/' ) ); ?>" class="cad-dev-code-form">
        <?php wp_nonce_field( 'cad_dev_verify_code', 'cad_dev_nonce' ); ?>
        <input type="hidden" name="cad_dev_verify_code" value="1" />
        <input type="hidden" name="cad_dev_session" value="<?php echo esc_attr( $session_id ); ?>" />

        <input
          type="text"
          name="cad_dev_code"
          class="cad-dev-code-input"
          placeholder="000000"
          maxlength="6"
          pattern="\d{6}"
          inputmode="numeric"
          autocomplete="one-time-code"
          autofocus
          required
        />

        <button type="submit" class="cad-dev-btn">
          Continue
        </button>
      </form>

      <a href="<?php echo esc_url( home_url( '/?cad_dev_login=1' ) ); ?>" class="cad-dev-back-link">
        ← Back to sign in
      </a>

    <?php elseif ( $sso_configured ) : ?>

      <!-- ── Layer 1: single "Sign In" button ──────────────────────── -->
      <div id="cad-dev-signin-wrap">
        <button id="cad-dev-signin-btn" class="cad-dev-btn" type="button">
          Sign in
        </button>
      </div>

      <!-- Spinner -->
      <div id="cad-dev-spinner" style="display:none;flex;text-align:center;padding:12px 0;color:#a1a1aa;font-size:13px;align-items:center;justify-content:center;gap:8px;">
        <span class="cad-dev-spinner-ring"></span>
        Checking access&hellip;
      </div>

      <!-- Blocked error -->
      <div id="cad-dev-blocked-error" class="cad-dev-error" style="display:none;"></div>

      <!-- ── Layer 2: login options (hidden until UNCERTAIN) ────────── -->
      <div id="cad-dev-options" style="display:none;flex-direction:column;gap:8px;">

        <!-- Google SSO -->
        <form method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" id="cad-dev-google-form">
          <input type="hidden" name="cad_dev_do_login" value="1" />
          <input type="hidden" name="cad_dev_fp_hash" id="cad-dev-fp-hash-google" value="" />
          <button type="submit" class="cad-dev-btn cad-dev-btn-secondary">
            <!-- Google G logo -->
            <svg class="cad-dev-btn-icon-google" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
              <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" fill="#4285F4"/>
              <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" fill="#34A853"/>
              <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" fill="#FBBC05"/>
              <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" fill="#EA4335"/>
            </svg>
            Continue with Google
          </button>
        </form>

        <?php if ( $plugin_configured ) : ?>
          <div class="cad-dev-divider"><span>or</span></div>

          <form method="post" action="<?php echo esc_url( home_url( '/' ) ); ?>" id="cad-dev-code-form">
            <?php wp_nonce_field( 'cad_dev_request_code', 'cad_dev_nonce' ); ?>
            <input type="hidden" name="cad_dev_request_code" value="1" />
            <input type="hidden" name="cad_dev_fp_hash" id="cad-dev-fp-hash-code" value="" />
            <button type="submit" class="cad-dev-btn cad-dev-btn-secondary">
              <svg class="cad-dev-btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <rect x="2" y="4" width="20" height="16" rx="2"/>
                <path d="m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7"/>
              </svg>
              Continue with Auth Code
            </button>
          </form>
        <?php endif; ?>

      </div><!-- #cad-dev-options -->

    <?php else : ?>

      <div class="cad-dev-error">
        SSO is not configured yet.<br>
        Please complete setup under <strong>Settings → Cad Dev SSO</strong>.
      </div>

    <?php endif; ?>

    <p class="cad-dev-footer">
      Access is restricted to authorized developers.<br>
      Contact your administrator if you need access.
    </p>

  </div><!-- .cad-dev-login-card -->

<?php if ( $step !== 'enter_code' && $sso_configured ) : ?>
<script>
(function () {
  var btn         = document.getElementById('cad-dev-signin-btn');
  var signinWrap  = document.getElementById('cad-dev-signin-wrap');
  var spinner     = document.getElementById('cad-dev-spinner');
  var options     = document.getElementById('cad-dev-options');
  var blockedErr  = document.getElementById('cad-dev-blocked-error');
  var fpGoogle    = document.getElementById('cad-dev-fp-hash-google');
  var fpCode      = document.getElementById('cad-dev-fp-hash-code');

  var ajaxUrl = <?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>;
  var nonce   = <?php echo wp_json_encode( wp_create_nonce( 'cad_dev_assess' ) ); ?>;

  btn.addEventListener('click', function () {
    btn.disabled = true;
    signinWrap.style.display = 'none';
    spinner.style.display    = 'flex';

    var params = new URLSearchParams({
      action:   'cad_dev_assess',
      nonce:    nonce,
      ua:       navigator.userAgent || '',
      screen_w: String(screen.width),
      screen_h: String(screen.height),
      tz:       (Intl && Intl.DateTimeFormat ? Intl.DateTimeFormat().resolvedOptions().timeZone : ''),
      lang:     navigator.language || '',
      platform: navigator.platform || ''
    });

    fetch(ajaxUrl, {
      method:      'POST',
      credentials: 'same-origin',
      headers:     { 'Content-Type': 'application/x-www-form-urlencoded' },
      body:        params.toString()
    })
    .then(function (r) { return r.json(); })
    .then(function (data) {
      spinner.style.display = 'none';

      if (data.decision === 'TRUSTED' && data.redirect) {
        window.location.href = data.redirect;
        return;
      }

      if (data.decision === 'BLOCKED') {
        blockedErr.textContent = data.message || 'Access denied.';
        blockedErr.style.display = 'block';
        return;
      }

      // UNCERTAIN — reveal Layer 2 options
      if (data.fp_hash) {
        if (fpGoogle) fpGoogle.value = data.fp_hash;
        if (fpCode)   fpCode.value   = data.fp_hash;
      }
      options.style.display = 'flex';
    })
    .catch(function () {
      spinner.style.display = 'none';
      options.style.display = 'flex';
      btn.disabled = false;
      signinWrap.style.display = 'block';
    });
  });
}());
</script>
<?php endif; ?>

</body>
</html>
