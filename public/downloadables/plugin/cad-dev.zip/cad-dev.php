<?php
/**
 * Plugin Name: Cad Dev
 * Plugin URI:  #
 * Description: SSO login for WordPress using Cad Dev SSO as the Identity Provider.
 * Version:     1.0.0
 * Author:      Cad Dev
 * License:     GPL2
 * Text Domain: cad-dev
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'CAD_DEV_VERSION',    '1.0.0' );
define( 'CAD_DEV_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'CAD_DEV_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

require_once CAD_DEV_PLUGIN_DIR . 'includes/class-jwt-verifier.php';
require_once CAD_DEV_PLUGIN_DIR . 'includes/class-sso-handler.php';
require_once CAD_DEV_PLUGIN_DIR . 'includes/class-login-page.php';
require_once CAD_DEV_PLUGIN_DIR . 'includes/class-auth-code.php';
require_once CAD_DEV_PLUGIN_DIR . 'includes/class-risk-assessment.php';
require_once CAD_DEV_PLUGIN_DIR . 'includes/class-push-login.php';

add_action( 'plugins_loaded', function () {
    new Cad_Dev_SSO_Handler();
    new Cad_Dev_Login_Page();
    new Cad_Dev_Auth_Code();
    new Cad_Dev_Risk_Assessment();
    new Cad_Dev_Push_Login();
} );

// ── Activation / Deactivation ─────────────────────────────────────────────────

register_activation_hook( __FILE__, 'cad_dev_activate' );
register_deactivation_hook( __FILE__, 'cad_dev_deactivate' );

function cad_dev_activate() {
    cad_dev_create_signals_table();

    if ( empty( get_option( 'cad_dev_site_id', '' ) ) ) {
        update_option( 'cad_dev_site_id', wp_generate_uuid4() );
    }

    // Register with the web app (non-blocking; may be a no-op if not configured yet)
    cad_dev_register_with_web_app();

    // Schedule the monthly health ping
    if ( ! wp_next_scheduled( 'cad_dev_monthly_ping' ) ) {
        wp_schedule_event( time(), 'cad_dev_monthly', 'cad_dev_monthly_ping' );
    }
}

function cad_dev_deactivate() {
    $timestamp = wp_next_scheduled( 'cad_dev_monthly_ping' );
    if ( $timestamp ) {
        wp_unschedule_event( $timestamp, 'cad_dev_monthly_ping' );
    }
}

// Register a custom 'monthly' WP-Cron interval (30 days)
add_filter( 'cron_schedules', function ( $schedules ) {
    if ( ! isset( $schedules['cad_dev_monthly'] ) ) {
        $schedules['cad_dev_monthly'] = [
            'interval' => 30 * DAY_IN_SECONDS,
            'display'  => 'Once Monthly (Cad Dev)',
        ];
    }
    return $schedules;
} );

// Monthly ping callback
add_action( 'cad_dev_monthly_ping', 'cad_dev_do_monthly_ping' );
function cad_dev_do_monthly_ping() {
    $sso_url       = get_option( 'cad_dev_sso_url', '' );
    $plugin_secret = get_option( 'cad_dev_plugin_secret', '' );
    $site_id       = get_option( 'cad_dev_site_id', '' );

    if ( empty( $sso_url ) || empty( $plugin_secret ) || empty( $site_id ) ) {
        return;
    }

    wp_remote_post(
        trailingslashit( $sso_url ) . 'auth/sites/ping',
        [
            'headers'  => [
                'x-plugin-secret' => $plugin_secret,
                'Content-Type'    => 'application/json',
            ],
            'body'     => wp_json_encode( [
                'site_id' => $site_id,
                'domain'  => home_url( '/' ),
            ] ),
            'timeout'  => 10,
            'blocking' => false,
            'sslverify' => true,
        ]
    );
}

// ── Shared Helper Functions ───────────────────────────────────────────────────

/**
 * Create (or update) the trusted signals table.
 * Safe to call multiple times — dbDelta handles existing tables.
 */
function cad_dev_create_signals_table() {
    global $wpdb;
    $table           = $wpdb->prefix . 'cad_dev_trusted_signals';
    $charset_collate = $wpdb->get_charset_collate();

    $sql = "CREATE TABLE {$table} (
        id bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
        user_id bigint(20) UNSIGNED NOT NULL,
        ip_address varchar(45) NOT NULL,
        fingerprint_hash varchar(64) NOT NULL,
        first_seen datetime NOT NULL,
        last_seen datetime NOT NULL,
        login_count int(11) UNSIGNED NOT NULL DEFAULT 1,
        PRIMARY KEY (id),
        KEY idx_user_id (user_id),
        KEY idx_ip_fp (ip_address(20), fingerprint_hash(20))
    ) {$charset_collate};";

    require_once ABSPATH . 'wp-admin/includes/upgrade.php';
    dbDelta( $sql );
}

/**
 * Save or update a trusted signal record after a successful login.
 *
 * @param int    $user_id
 * @param string $ip_address
 * @param string $fingerprint_hash  SHA-256 hex string
 */
function cad_dev_save_trusted_signal( $user_id, $ip_address, $fingerprint_hash ) {
    if ( empty( $ip_address ) || empty( $fingerprint_hash ) ) {
        return;
    }

    global $wpdb;
    $table = $wpdb->prefix . 'cad_dev_trusted_signals';
    $now   = current_time( 'mysql' );

    $existing_id = $wpdb->get_var( $wpdb->prepare(
        "SELECT id FROM {$table} WHERE user_id = %d AND ip_address = %s AND fingerprint_hash = %s",
        $user_id, $ip_address, $fingerprint_hash
    ) );

    if ( $existing_id ) {
        $wpdb->query( $wpdb->prepare(
            "UPDATE {$table} SET last_seen = %s, login_count = login_count + 1 WHERE id = %d",
            $now, $existing_id
        ) );
    } else {
        $wpdb->insert(
            $table,
            [
                'user_id'          => (int) $user_id,
                'ip_address'       => $ip_address,
                'fingerprint_hash' => $fingerprint_hash,
                'first_seen'       => $now,
                'last_seen'        => $now,
                'login_count'      => 1,
            ],
            [ '%d', '%s', '%s', '%s', '%s', '%d' ]
        );
    }
}

/**
 * Get the client's real IP address.
 * Checks proxy headers commonly set by hosting environments / CDNs.
 */
function cad_dev_get_client_ip() {
    $ip = '';

    if ( ! empty( $_SERVER['HTTP_CF_CONNECTING_IP'] ) ) {
        $ip = $_SERVER['HTTP_CF_CONNECTING_IP']; // Cloudflare
    } elseif ( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
        $parts = explode( ',', $_SERVER['HTTP_X_FORWARDED_FOR'] );
        $ip    = trim( $parts[0] );
    } elseif ( ! empty( $_SERVER['HTTP_X_REAL_IP'] ) ) {
        $ip = $_SERVER['HTTP_X_REAL_IP'];
    } elseif ( ! empty( $_SERVER['REMOTE_ADDR'] ) ) {
        $ip = $_SERVER['REMOTE_ADDR'];
    }

    return filter_var( $ip, FILTER_VALIDATE_IP ) ? $ip : '';
}

/**
 * Set the long-lived Cad Dev session cookie after a successful login.
 * The cookie value is HMAC-signed with the PLUGIN_SECRET to prevent forgery.
 *
 * @param string $email  The authenticated user's email.
 */
function cad_dev_set_session_cookie( $email ) {
    $plugin_secret = get_option( 'cad_dev_plugin_secret', '' );
    if ( empty( $plugin_secret ) || ! is_email( $email ) ) {
        return;
    }

    $timestamp = (string) time();
    $hmac      = hash_hmac( 'sha256', $email . '|' . $timestamp, $plugin_secret );
    $value     = $email . '|' . $timestamp . '|' . $hmac;

    setcookie( 'cad_dev_session', $value, [
        'expires'  => time() + 30 * DAY_IN_SECONDS,
        'path'     => '/',
        'secure'   => is_ssl(),
        'httponly' => true,
        'samesite' => 'Lax',
    ] );
}

/**
 * Verify the Cad Dev session cookie and return the email it encodes.
 *
 * @return string|null  Email address, or null if the cookie is absent/invalid/expired.
 */
function cad_dev_verify_session_cookie() {
    if ( empty( $_COOKIE['cad_dev_session'] ) ) {
        return null;
    }

    $parts = explode( '|', $_COOKIE['cad_dev_session'], 3 );
    if ( count( $parts ) !== 3 ) {
        return null;
    }

    [ $email, $timestamp, $given_hmac ] = $parts;

    // Cookie must not be older than 30 days
    if ( (int) $timestamp < time() - 30 * DAY_IN_SECONDS ) {
        return null;
    }

    $plugin_secret = get_option( 'cad_dev_plugin_secret', '' );
    if ( empty( $plugin_secret ) ) {
        return null;
    }

    $expected_hmac = hash_hmac( 'sha256', $email . '|' . $timestamp, $plugin_secret );
    if ( ! hash_equals( $expected_hmac, $given_hmac ) ) {
        return null;
    }

    return is_email( $email ) ? $email : null;
}

/**
 * Register (or update) this site with the Cad Dev SSO web app.
 * Fire-and-forget — non-blocking, failures are silent.
 */
function cad_dev_register_with_web_app() {
    $sso_url       = get_option( 'cad_dev_sso_url', '' );
    $plugin_secret = get_option( 'cad_dev_plugin_secret', '' );

    if ( empty( $sso_url ) || empty( $plugin_secret ) ) {
        return; // Not configured yet
    }

    wp_remote_post(
        trailingslashit( $sso_url ) . 'auth/sites/register',
        [
            'headers'  => [
                'x-plugin-secret' => $plugin_secret,
                'Content-Type'    => 'application/json',
            ],
            'body'     => wp_json_encode( [
                'site_id'        => get_option( 'cad_dev_site_id', '' ),
                'domain'         => home_url( '/' ),
                'owner_email'    => get_option( 'cad_dev_owner_email', '' ) ?: null,
                'plugin_version' => CAD_DEV_VERSION,
            ] ),
            'timeout'  => 10,
            'blocking' => false,
            'sslverify' => true,
        ]
    );
}

// ── Admin settings ────────────────────────────────────────────────────────────

// ── Admin Bar Badge ───────────────────────────────────────────────────────────

/**
 * Show a "Cad Dev SSO" badge in the admin bar for all logged-in users.
 * Communicates that this site's access is controlled by Cad Dev SSO.
 * Owners get a link to the settings page; other users see it as a plain label.
 */
add_action( 'admin_bar_menu', 'cad_dev_admin_bar_badge', 7 );
function cad_dev_admin_bar_badge( WP_Admin_Bar $wp_admin_bar ) {
    if ( ! is_user_logged_in() ) {
        return;
    }
    if ( empty( get_option( 'cad_dev_sso_url', '' ) ) ) {
        return; // Plugin not configured — stay silent
    }

    $href = cad_dev_current_user_is_owner()
        ? admin_url( 'options-general.php?page=cad-dev-sso' )
        : false;

    $icon = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none"'
          . ' stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"'
          . ' class="cad-dev-ab-icon">'
          . '<rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>'
          . '<path d="M7 11V7a5 5 0 0 1 10 0v4"/>'
          . '</svg>';

    $class = 'cad-dev-ab-node' . ( $href ? ' cad-dev-ab-node--owner' : '' );

    $wp_admin_bar->add_node( [
        'id'    => 'cad-dev-sso-badge',
        'title' => $icon . '<span class="cad-dev-ab-label">Cad Dev SSO</span>',
        'href'  => $href,
        'meta'  => [
            'title' => 'This site is secured by Cad Dev SSO',
            'class' => $class,
        ],
    ] );
}

add_action( 'admin_head', 'cad_dev_admin_bar_styles' );
add_action( 'wp_head',    'cad_dev_admin_bar_styles' );
function cad_dev_admin_bar_styles() {
    if ( ! is_admin_bar_showing() || ! is_user_logged_in() ) {
        return;
    }
    ?>
    <style id="cad-dev-ab-styles">
    #wpadminbar #wp-admin-bar-cad-dev-sso-badge > .ab-item {
        display: flex !important;
        align-items: center !important;
        gap: 5px !important;
        color: #7dd3fc !important;
        font-weight: 500 !important;
        letter-spacing: 0.01em !important;
        cursor: default !important;
    }
    #wpadminbar #wp-admin-bar-cad-dev-sso-badge.cad-dev-ab-node--owner > .ab-item {
        cursor: pointer !important;
    }
    #wpadminbar #wp-admin-bar-cad-dev-sso-badge > .ab-item:hover {
        color: #fff !important;
        background: transparent !important;
    }
    #wpadminbar .cad-dev-ab-icon {
        width: 13px !important;
        height: 13px !important;
        display: inline-block !important;
        vertical-align: middle !important;
        flex-shrink: 0 !important;
        stroke: currentColor !important;
    }
    #wpadminbar .cad-dev-ab-label {
        line-height: 1 !important;
    }
    </style>
    <?php
}

// ── Visibility: hide plugin from everyone except the designated owner ──────────

/**
 * Returns true if the current user is the Cad Dev plugin owner.
 * The owner email is stored in wp_options as 'cad_dev_owner_email'.
 * On first activation (no owner set yet) only the activating super-admin sees it.
 */
function cad_dev_current_user_is_owner() {
    $owner_email = get_option( 'cad_dev_owner_email', '' );

    // No owner configured yet — fall back to checking for the manage_options cap
    // so the plugin stays visible until the owner is set.
    if ( empty( $owner_email ) ) {
        return current_user_can( 'manage_options' );
    }

    $current_user = wp_get_current_user();
    return $current_user && strtolower( $current_user->user_email ) === strtolower( $owner_email );
}

/**
 * Remove this plugin from the plugins list for non-owners.
 */
add_filter( 'all_plugins', function ( $plugins ) {
    if ( cad_dev_current_user_is_owner() ) {
        return $plugins;
    }
    // The key is the plugin's path relative to the plugins directory.
    unset( $plugins[ plugin_basename( __FILE__ ) ] );
    return $plugins;
} );

/**
 * Also hide the Settings → Cad Dev SSO menu item from non-owners.
 */
add_action( 'admin_menu', 'cad_dev_admin_menu' );
function cad_dev_admin_menu() {
    if ( ! cad_dev_current_user_is_owner() ) {
        return;
    }
    add_options_page(
        'Cad Dev SSO',
        'Cad Dev SSO',
        'manage_options',
        'cad-dev-sso',
        'cad_dev_settings_page'
    );
}

add_action( 'admin_init', 'cad_dev_register_settings' );
function cad_dev_register_settings() {
    register_setting( 'cad_dev_sso', 'cad_dev_sso_url',       [ 'sanitize_callback' => 'esc_url_raw' ] );
    register_setting( 'cad_dev_sso', 'cad_dev_public_key',    [ 'sanitize_callback' => 'sanitize_textarea_field' ] );
    register_setting( 'cad_dev_sso', 'cad_dev_default_role',  [ 'sanitize_callback' => 'sanitize_text_field' ] );
    register_setting( 'cad_dev_sso', 'cad_dev_plugin_secret', [ 'sanitize_callback' => 'sanitize_text_field' ] );
    // cad_dev_owner_email is set automatically on first SSO login — not user-editable.
}

function cad_dev_settings_page() {
    $login_url    = home_url( '/?cad_dev_login=1' );
    $callback_url = home_url( '/?cad_dev_callback=1' );
    ?>
    <div class="wrap">
        <h1>Cad Dev SSO Settings</h1>

        <form method="post" action="options.php">
            <?php settings_fields( 'cad_dev_sso' ); ?>
            <table class="form-table">

                <tr>
                    <th><label for="cad_dev_sso_url">Cad Dev SSO URL</label></th>
                    <td>
                        <input type="url" id="cad_dev_sso_url" name="cad_dev_sso_url"
                               value="<?php echo esc_attr( get_option( 'cad_dev_sso_url', '' ) ); ?>"
                               class="regular-text" placeholder="https://your-sso-app.com" />
                        <p class="description">Base URL of your Cad Dev SSO web app (no trailing slash).</p>
                    </td>
                </tr>

                <tr>
                    <th><label for="cad_dev_public_key">RSA Public Key</label></th>
                    <td>
                        <textarea id="cad_dev_public_key" name="cad_dev_public_key"
                                  rows="10" cols="60" class="large-text code"
                                  placeholder="-----BEGIN PUBLIC KEY-----&#10;...&#10;-----END PUBLIC KEY-----"
                        ><?php echo esc_textarea( get_option( 'cad_dev_public_key', '' ) ); ?></textarea>
                        <p class="description">
                            Contents of <code>keys/public.pem</code> from your Cad Dev SSO app.<br>
                            You can also fetch it via: <code>GET /admin/public-key</code> (requires ADMIN_SECRET).
                        </p>
                    </td>
                </tr>

                <tr>
                    <th><label for="cad_dev_plugin_secret">Plugin Secret</label></th>
                    <td>
                        <input type="password" id="cad_dev_plugin_secret" name="cad_dev_plugin_secret"
                               value="<?php echo esc_attr( get_option( 'cad_dev_plugin_secret', '' ) ); ?>"
                               class="regular-text" autocomplete="new-password" />
                        <p class="description">
                            Must match <code>PLUGIN_SECRET</code> in your Cad Dev SSO <code>.env</code>.<br>
                            This authenticates requests from this plugin to the web app's auth-code endpoints.
                        </p>
                    </td>
                </tr>

                <tr>
                    <th><label for="cad_dev_default_role">Default Role for SSO Users</label></th>
                    <td>
                        <select id="cad_dev_default_role" name="cad_dev_default_role">
                            <?php
                            $current = get_option( 'cad_dev_default_role', 'administrator' );
                            foreach ( wp_roles()->get_names() as $role => $name ) {
                                printf(
                                    '<option value="%s"%s>%s</option>',
                                    esc_attr( $role ),
                                    selected( $current, $role, false ),
                                    esc_html( $name )
                                );
                            }
                            ?>
                        </select>
                        <p class="description">Role assigned to new users created via SSO.</p>
                    </td>
                </tr>

            </table>
            <?php submit_button(); ?>
        </form>

        <hr>
        <h2>Plugin Visibility</h2>
        <?php $owner = get_option( 'cad_dev_owner_email', '' ); ?>
        <?php if ( $owner ) : ?>
            <p>
                This plugin is visible only to <strong><?php echo esc_html( $owner ); ?></strong>.<br>
                That account was automatically registered on their first SSO login.
            </p>
        <?php else : ?>
            <div class="notice notice-warning inline">
                <p>No owner registered yet. The plugin will be visible to all admins until someone logs in via SSO for the first time.</p>
            </div>
        <?php endif; ?>

        <hr>
        <h2>Trusted Signal History</h2>
        <?php
        global $wpdb;
        $table   = $wpdb->prefix . 'cad_dev_trusted_signals';
        $signals = $wpdb->get_results(
            "SELECT s.*, u.user_email
               FROM {$table} s
               LEFT JOIN {$wpdb->users} u ON u.ID = s.user_id
              ORDER BY s.last_seen DESC
              LIMIT 50"
        );
        if ( $signals ) :
        ?>
        <table class="widefat striped" style="margin-top:10px">
            <thead>
                <tr>
                    <th>User</th>
                    <th>IP Address</th>
                    <th>Fingerprint (truncated)</th>
                    <th>First Seen</th>
                    <th>Last Seen</th>
                    <th>Logins</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ( $signals as $row ) : ?>
                <tr>
                    <td><?php echo esc_html( $row->user_email ?: "User #{$row->user_id}" ); ?></td>
                    <td><code><?php echo esc_html( $row->ip_address ); ?></code></td>
                    <td><code><?php echo esc_html( substr( $row->fingerprint_hash, 0, 12 ) . '...' ); ?></code></td>
                    <td><?php echo esc_html( $row->first_seen ); ?></td>
                    <td><?php echo esc_html( $row->last_seen ); ?></td>
                    <td><?php echo (int) $row->login_count; ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        <?php else : ?>
        <p class="description">No trusted signals recorded yet. They are saved automatically after each successful login.</p>
        <?php endif; ?>

        <hr>
        <h2>Plugin Endpoints</h2>
        <table class="form-table">
            <tr>
                <th>Login Page</th>
                <td>
                    <a href="<?php echo esc_url( $login_url ); ?>" target="_blank">
                        <?php echo esc_html( $login_url ); ?>
                    </a>
                    <p class="description">Send your developers here to log in.</p>
                </td>
            </tr>
            <tr>
                <th>Callback URL</th>
                <td>
                    <code><?php echo esc_html( $callback_url ); ?></code>
                    <p class="description">
                        Add this to <strong>ALLOWED_REDIRECT_ORIGINS</strong> in your Cad Dev SSO <code>.env</code> file.
                    </p>
                </td>
            </tr>
        </table>
    </div>
    <?php
}
