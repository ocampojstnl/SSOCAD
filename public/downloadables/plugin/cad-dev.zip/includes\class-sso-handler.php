<?php
/**
 * Handles the SSO callback — verifies the JWT and logs the user in.
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

class Cad_Dev_SSO_Handler {

    public function __construct() {
        // Run at priority 1 so we can redirect before any output
        add_action( 'init', [ $this, 'handle_callback' ], 1 );
    }

    /**
     * Triggered when WordPress boots with ?cad_dev_callback=1.
     */
    public function handle_callback() {
        if ( empty( $_GET['cad_dev_callback'] ) ) {
            return;
        }

        // Read the raw JWT — do NOT use sanitize_text_field() on it because that
        // function strips dots and special characters that are part of a valid JWT.
        $token = isset( $_GET['token'] ) ? wp_unslash( $_GET['token'] ) : '';
        $state = sanitize_text_field( wp_unslash( $_GET['state'] ?? '' ) );

        // Validate token is a plausible JWT (3 base64url segments)
        if ( empty( $token ) || substr_count( $token, '.' ) !== 2 || ! preg_match( '/^[A-Za-z0-9\-_]+\.[A-Za-z0-9\-_]+\.[A-Za-z0-9\-_]+$/', $token ) ) {
            wp_die( 'Cad Dev SSO: Invalid token format.', 'SSO Error', [ 'response' => 400 ] );
        }

        // --- Validate state (CSRF) — state is always required ---
        if ( empty( $state ) ) {
            wp_die( 'Cad Dev SSO: Missing state parameter. Possible CSRF attack.', 'SSO Error', [ 'response' => 403 ] );
        }

        $transient_key = 'cad_dev_state_' . substr( $state, 0, 64 );
        $stored_state  = get_transient( $transient_key );

        if ( $stored_state === false ) {
            wp_die( 'Cad Dev SSO: Invalid or expired state. Please try logging in again.', 'SSO Error', [ 'response' => 403 ] );
        }

        // Consume the state — one-time use
        delete_transient( $transient_key );

        // --- Verify JWT ---
        $public_key = get_option( 'cad_dev_public_key', '' );
        if ( empty( $public_key ) ) {
            wp_die( 'Cad Dev SSO: Public key not configured. Go to Settings → Cad Dev SSO.', 'SSO Error', [ 'response' => 500 ] );
        }

        $expected_issuer = get_option( 'cad_dev_sso_url', '' );
        $verifier        = new Cad_Dev_JWT_Verifier( $public_key, $expected_issuer );
        $payload         = $verifier->verify( $token );

        if ( ! $payload ) {
            wp_die( 'Cad Dev SSO: Invalid or expired token. Please try logging in again.', 'SSO Error', [ 'response' => 403 ] );
        }

        // --- Replay prevention: reject already-used JTIs ---
        $jti           = $payload['jti'];
        $jti_key       = 'cad_dev_jti_' . hash( 'sha256', $jti ); // hash to keep key length safe
        $jti_used      = get_transient( $jti_key );

        if ( $jti_used !== false ) {
            wp_die( 'Cad Dev SSO: Token has already been used. Please log in again.', 'SSO Error', [ 'response' => 403 ] );
        }

        // Mark JTI as used — store for 6 min (1 min beyond the 5 min JWT expiry)
        set_transient( $jti_key, '1', 6 * MINUTE_IN_SECONDS );

        // --- Extract claims ---
        $email = sanitize_email( $payload['email'] ?? '' );
        $name  = sanitize_text_field( $payload['name'] ?? '' );

        if ( ! is_email( $email ) ) {
            wp_die( 'Cad Dev SSO: Token contains an invalid email.', 'SSO Error', [ 'response' => 400 ] );
        }

        // --- Find or create the WP user ---
        $user = get_user_by( 'email', $email );

        if ( ! $user ) {
            $username = sanitize_user( strstr( $email, '@', true ) );
            if ( username_exists( $username ) ) {
                $username = $username . '_' . wp_generate_password( 4, false );
            }

            $role    = get_option( 'cad_dev_default_role', 'administrator' );
            $user_id = wp_insert_user( [
                'user_login'   => $username,
                'user_email'   => $email,
                'display_name' => $name ?: $username,
                'user_pass'    => wp_generate_password( 32 ),
                'role'         => $role,
            ] );

            if ( is_wp_error( $user_id ) ) {
                wp_die(
                    'Cad Dev SSO: Failed to create user account: ' . esc_html( $user_id->get_error_message() ),
                    'SSO Error',
                    [ 'response' => 500 ]
                );
            }

            $user = get_user_by( 'id', $user_id );
        }

        // --- Log the user in ---
        wp_set_current_user( $user->ID );
        wp_set_auth_cookie( $user->ID, true );
        do_action( 'wp_login', $user->user_login, $user );

        // --- Auto-register the first SSO login as the plugin owner ---
        if ( empty( get_option( 'cad_dev_owner_email', '' ) ) ) {
            update_option( 'cad_dev_owner_email', $user->user_email );
        }

        // --- Save trusted signal so this device is auto-trusted next time (Layer 1) ---
        $fp_hash = get_transient( 'cad_dev_fp_' . $state );
        if ( $fp_hash ) {
            delete_transient( 'cad_dev_fp_' . $state );
            cad_dev_save_trusted_signal( $user->ID, cad_dev_get_client_ip(), $fp_hash );
        }
        cad_dev_set_session_cookie( $user->user_email );
        cad_dev_register_with_web_app();

        wp_safe_redirect( admin_url() );
        exit;
    }
}
