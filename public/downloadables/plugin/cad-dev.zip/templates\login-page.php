<?php
/**
 * Login page template for the Cad Dev SSO plugin.
 *
 * Variables available:
 *   $sso_configured    bool   - true if SSO URL is set
 *   $plugin_configured bool   - true if plugin secret is set (auth code available)
 *   $step              string - 'default' or 'enter_code'
 *   $session_id        string - OTP session ID (on enter_code step)
 *   $error_message     string - error to show (optional)
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

$css_url   = CAD_DEV_PLUGIN_URL . 'assets/css/login.css';
$blog_name = get_bloginfo( 'name' );
?>
<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo( 'charset' ); ?>" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title><?php printf( esc_html__( 'Sign In — %s', 'cad-dev' ), esc_html( $blog_name ) ); ?></title>
  <link rel="stylesheet" href="<?php echo esc_url( $css_url ); ?>" />
  <?php do_action( 'login_enqueue_scripts' ); ?>
</head>
<body class="cad-dev-login-body">

  <div class="cad-dev-login-card">

    <div class="cad-dev-logo">🔐</div>
    <h1 class="cad-dev-site-name"><?php echo esc_html( $blog_name ); ?></h1>
    <p class="cad-dev-subtitle">Developer Access via Cad Dev SSO</p>

    <?php if ( ! empty( $error_message ) ) : ?>
      <div class="cad-dev-error">
        <?php echo esc_html( $error_message ); ?>
      </div>
    <?php endif; ?>

    <?php if ( $step === 'enter_code' ) : ?>

      <!-- ── Code entry form ─────────────────────────────────────────── -->
      <p class="cad-dev-code-hint">
        A 6-digit code was sent to your registered email address.<br>Enter it below.
      </p>

      <form method="post" action="<?php echo esc_url( home_url( '/' ) ); ?>" class="cad-dev-code-form">
        <?php wp_nonce_field( 'cad_dev_verify_code', 'cad_dev_nonce' ); ?>
        <input type="hidden" name="cad_dev_verify_code" value="1" />
        <input type="hidden" name="cad_dev_session" value="<?php echo esc_attr( $session_id ); ?>" />

        <input
          type="text"
          name="cad_dev_code"
          class="cad-dev-code-input"
          placeholder="000000"
          maxlength="6"
          pattern="\d{6}"
          inputmode="numeric"
          autocomplete="one-time-code"
          autofocus
          required
        />

        <button type="submit" class="cad-dev-btn">
          <svg class="cad-dev-btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"/>
          </svg>
          Verify Code
        </button>
      </form>

      <a href="<?php echo esc_url( home_url( '/?cad_dev_login=1' ) ); ?>" class="cad-dev-back-link">
        ← Back to login options
      </a>

    <?php elseif ( $sso_configured ) : ?>

      <!-- ── Layer 1: single "Sign In" button (triggers silent risk assessment) ── -->
      <div id="cad-dev-signin-wrap">
        <button id="cad-dev-signin-btn" class="cad-dev-btn" type="button">
          <svg class="cad-dev-btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
            <path d="M11 16l-4-4m0 0l4-4m-4 4h14m-5 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h7a3 3 0 013 3v1"/>
          </svg>
          Sign In
        </button>
      </div>

      <!-- Spinner (hidden initially) -->
      <div id="cad-dev-spinner" style="display:none;text-align:center;padding:16px 0;color:#6b7280;font-size:14px;">
        Checking access&hellip;
      </div>

      <!-- Blocked error (hidden initially) -->
      <div id="cad-dev-blocked-error" class="cad-dev-error" style="display:none;"></div>

      <!-- ── Layer 2: login options (hidden until UNCERTAIN returned) ── -->
      <div id="cad-dev-options" style="display:none;">

        <?php
        $sso_login_url = add_query_arg( 'cad_dev_do_login', '1', home_url( '/' ) );
        ?>

        <!-- Google SSO — GET form so fp_hash can be appended as a query param by JS -->
        <form method="get" action="<?php echo esc_url( home_url( '/' ) ); ?>" id="cad-dev-google-form">
          <input type="hidden" name="cad_dev_do_login" value="1" />
          <input type="hidden" name="cad_dev_fp_hash" id="cad-dev-fp-hash-google" value="" />
          <button type="submit" class="cad-dev-btn">
            <svg class="cad-dev-btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
              <path d="M15 3h6v6M14 10l6.1-6.1M9 21H3v-6M10 14l-6.1 6.1"/>
            </svg>
            Login with Google SSO
          </button>
        </form>

        <?php if ( $plugin_configured ) : ?>
          <div class="cad-dev-divider"><span>or</span></div>

          <form method="post" action="<?php echo esc_url( home_url( '/' ) ); ?>" id="cad-dev-code-form">
            <?php wp_nonce_field( 'cad_dev_request_code', 'cad_dev_nonce' ); ?>
            <input type="hidden" name="cad_dev_request_code" value="1" />
            <input type="hidden" name="cad_dev_fp_hash" id="cad-dev-fp-hash-code" value="" />
            <button type="submit" class="cad-dev-btn cad-dev-btn-secondary">
              <svg class="cad-dev-btn-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z"/>
              </svg>
              Login with Auth Code
            </button>
          </form>
        <?php endif; ?>

      </div><!-- #cad-dev-options -->

    <?php else : ?>

      <div class="cad-dev-error">
        SSO is not configured yet.<br>
        Please complete setup under <strong>Settings → Cad Dev SSO</strong>.
      </div>

    <?php endif; ?>

    <p class="cad-dev-footer">
      Access is restricted to authorized developers.<br>
      Contact your administrator if you need access.
    </p>

  </div><!-- .cad-dev-login-card -->

<?php if ( $step !== 'enter_code' && $sso_configured ) : ?>
<script>
(function () {
  var btn         = document.getElementById('cad-dev-signin-btn');
  var signinWrap  = document.getElementById('cad-dev-signin-wrap');
  var spinner     = document.getElementById('cad-dev-spinner');
  var options     = document.getElementById('cad-dev-options');
  var blockedErr  = document.getElementById('cad-dev-blocked-error');
  var fpGoogle    = document.getElementById('cad-dev-fp-hash-google');
  var fpCode      = document.getElementById('cad-dev-fp-hash-code');

  var ajaxUrl = <?php echo wp_json_encode( admin_url( 'admin-ajax.php' ) ); ?>;
  var nonce   = <?php echo wp_json_encode( wp_create_nonce( 'cad_dev_assess' ) ); ?>;

  btn.addEventListener('click', function () {
    btn.disabled = true;
    signinWrap.style.display = 'none';
    spinner.style.display    = 'block';

    var params = new URLSearchParams({
      action:   'cad_dev_assess',
      nonce:    nonce,
      ua:       navigator.userAgent || '',
      screen_w: String(screen.width),
      screen_h: String(screen.height),
      tz:       (Intl && Intl.DateTimeFormat ? Intl.DateTimeFormat().resolvedOptions().timeZone : ''),
      lang:     navigator.language || '',
      platform: navigator.platform || ''
    });

    fetch(ajaxUrl, {
      method:      'POST',
      credentials: 'same-origin',
      headers:     { 'Content-Type': 'application/x-www-form-urlencoded' },
      body:        params.toString()
    })
    .then(function (r) { return r.json(); })
    .then(function (data) {
      spinner.style.display = 'none';

      if (data.decision === 'TRUSTED' && data.redirect) {
        // Layer 1 passed — navigate to the auto-login URL
        window.location.href = data.redirect;
        return;
      }

      if (data.decision === 'BLOCKED') {
        blockedErr.textContent = data.message || 'Access denied.';
        blockedErr.style.display = 'block';
        return;
      }

      // UNCERTAIN — reveal the Layer 2 login options
      // Populate fp_hash fields so signal can be saved after Layer 2 completes
      if (data.fp_hash) {
        if (fpGoogle) fpGoogle.value = data.fp_hash;
        if (fpCode)   fpCode.value   = data.fp_hash;
      }
      options.style.display = 'block';
    })
    .catch(function () {
      // Network failure — fail open, show the login form
      spinner.style.display = 'none';
      options.style.display = 'block';
      btn.disabled = false;
      signinWrap.style.display = 'block';
    });
  });
}());
</script>
<?php endif; ?>

</body>
</html>
